Program can be run with the following command:
python3 SmartClient.py <website_name>